tinymce.init({
    selector: 'textarea'
  });